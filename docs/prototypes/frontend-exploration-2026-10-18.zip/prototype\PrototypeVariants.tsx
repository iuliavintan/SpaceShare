import { useState, type FormEvent } from 'react';
import { Icon } from '../../components/Icon';
import { pages, type PrototypeData } from './prototype.types';

const resources = [
  { number: '01', icon: 'room', name: 'Săli de studiu', text: 'Pentru concentrare și proiecte de grup.' },
  { number: '02', icon: 'lab', name: 'Laboratoare', text: 'Locul în care ideile devin experimente.' },
  { number: '03', icon: 'screen', name: 'Echipamente', text: 'Instrumente pe care le folosim împreună.' },
] as const;

function Brand() {
  return <a href="#/" className="pt-brand"><svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true"><rect x="3" y="3" width="17" height="17" rx="3" stroke="currentColor" strokeWidth="2" /><rect x="12" y="12" width="17" height="17" rx="3" fill="var(--pt-bg)" stroke="currentColor" strokeWidth="2" /></svg>SpaceShare<span>.</span></a>;
}

function AccountLinks(data: PrototypeData) {
  return <nav className="pt-account-links" aria-label="Navigare cont">
    {data.signedIn ? <><a href="#/profile">Profilul meu</a><button type="button" className="pt-link-button" onClick={data.signOut}>Deconectare ↗</button></> : <><a href="#/login">Autentificare</a><a className="pt-button" href="#/register">Creează cont <span>↗</span></a></>}
  </nav>;
}

function AccountForm(data: PrototypeData) {
  const profile = data.page === 'profile';
  const register = data.page === 'register';
  const [name, setName] = useState(profile ? data.user.name : '');
  const [email, setEmail] = useState(profile ? data.user.email : '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const title = profile ? 'Informații personale' : register ? 'Creează-ți contul' : 'Bine ai revenit';

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    data.saveUser({ name: name || data.user.name, email });
    setPassword('');
    if (!profile) data.navigate('profile');
  }

  return <section className="pt-form-panel" aria-labelledby="prototype-form-title">
    <span className="pt-overline">{profile ? 'PROFIL / DATE DE BAZĂ' : register ? 'PRIMUL PAS ÎN COMUNITATE' : 'CONTUL TĂU SPACESHARE'}</span>
    <h2 id="prototype-form-title">{title}<span>.</span></h2>
    <p className="pt-form-description">{profile ? 'Păstrează-ți datele la zi, într-un singur loc.' : register ? 'Câteva detalii și ești parte din comunitate.' : 'Intră în cont folosind adresa ta de email.'}</p>
    <form onSubmit={submit}>
      <fieldset disabled={data.formState === 'loading'}>
        {(register || profile) && <label>Nume complet<input required minLength={2} maxLength={80} name="name" autoComplete="off" placeholder="Cum te numești?" value={name} onChange={(event) => setName(event.target.value)} /></label>}
        <label>Adresa de email<input required type="email" name="email" autoComplete="off" placeholder="nume@universitate.ro" value={email} onChange={(event) => setEmail(event.target.value)} /></label>
        {!profile && <label>Parolă<span className="pt-password-input"><input required type={showPassword ? 'text' : 'password'} minLength={8} maxLength={72} autoComplete="new-password" placeholder="Cel puțin 8 caractere" value={password} onChange={(event) => setPassword(event.target.value)} /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-pressed={showPassword}>{showPassword ? 'Ascunde' : 'Arată'}</button></span></label>}
        {data.formState === 'error' && <p className="pt-feedback error" role="alert">{profile || register ? 'Această adresă de email este deja folosită.' : 'Email sau parolă incorectă. Încearcă din nou.'}</p>}
        {data.formState === 'success' && <p className="pt-feedback success" role="status">{profile ? 'Modificările demonstrative au fost salvate.' : 'Formular completat cu succes în simulare.'}</p>}
        <button className="pt-button pt-submit" type="submit">{data.formState === 'loading' ? 'Se procesează…' : profile ? 'Salvează modificările' : register ? 'Creează cont' : 'Autentifică-te'} <span>↗</span></button>
      </fieldset>
    </form>
    {profile ? <p className="pt-form-footnote">Rol: Utilizator <span>·</span> Cont demonstrativ</p> : <p className="pt-form-footnote">{register ? 'Ai deja un cont?' : 'Ești nou aici?'} <a href={register ? '#/login' : '#/register'}>{register ? 'Autentifică-te' : 'Creează un cont'}</a></p>}
  </section>;
}

function FloorPlan() {
  return <div className="pt-floorplan" role="img" aria-label="Plan ilustrativ al unui spațiu de studiu comun">
    <div className="pt-plan-label">UN LOC PENTRU IDEILE TALE</div>
    <div className="pt-plan-room"><span className="pt-plan-door" /><span className="pt-plan-table" /><span className="pt-plan-chair c1" /><span className="pt-plan-chair c2" /><span className="pt-plan-chair c3" /><span className="pt-plan-chair c4" /><span className="pt-plan-window" /><span className="pt-plan-plant">✳</span></div>
    <span className="pt-plan-caption">SPACES / STUDY / TOGETHER</span><span className="pt-plan-compass">N ↑</span>
  </div>;
}

export function VariantA(data: PrototypeData) {
  return <div className="pt-editorial">
    <header className="pt-editorial-header"><Brand /><a className="pt-editorial-motto" href="#/">Spații comune. Idei mari.</a><AccountLinks {...data} /></header>
    {data.page === 'home' ? <main>
      <section className="pt-editorial-hero"><div><p className="pt-overline">PENTRU COMUNITATEA UNIVERSITARĂ</p><h1>Un loc bun<br />pentru <em>ce urmează.</em></h1><p>Spațiile în care învățăm, lucrăm și construim împreună merită să fie mai ușor de găsit.</p><a className="pt-button" href="#/register">Fă parte din comunitate <span>↗</span></a><span className="pt-small-note">Săli, laboratoare și echipamente. În curând, într-un singur loc.</span></div><FloorPlan /></section>
      <section className="pt-editorial-resources"><div><p className="pt-overline">RESURSE COMUNE</p><h2>Mai mult loc.<br />Mai multe posibilități.</h2></div><div>{resources.map((item) => <article key={item.number}><span>{item.number}</span><div><h3>{item.name}</h3><p>{item.text}</p></div><Icon name={item.icon} className="size-6" /></article>)}</div></section>
    </main> : <main className="pt-editorial-account"><aside><p className="pt-overline">{data.page === 'profile' ? 'COMUNITATEA ÎNCEPE CU TINE' : 'SPACESHARE / CONTUL TĂU'}</p><h1>{data.page === 'profile' ? <>Salut,<br /><em>{data.user.name.split(' ')[0]}.</em></> : <>Ideile bune<br />au nevoie<br />de <em>spațiu.</em></>}</h1><p>{data.page === 'profile' ? 'Numele tău, datele tale. Un profil simplu, care te reprezintă.' : 'Un loc pentru învățare, colaborare și lucrurile pe care le facem împreună.'}</p><a href="#/">← Înapoi acasă</a><span className="pt-editorial-stamp">S<span>Comunitate<br />universitară</span></span></aside><AccountForm key={data.page} {...data} /></main>}
    <footer className="pt-editorial-footer"><span>SpaceShare — Spațiile ne aduc împreună.</span><span>Proiect universitar / În dezvoltare</span></footer>
  </div>;
}

export function VariantB(data: PrototypeData) {
  return <div className="pt-workspace">
    <aside className="pt-workspace-sidebar"><Brand /><span className="pt-workspace-org">SPAȚIUL COMUNITĂȚII</span><nav aria-label="Navigare principală">{(['home', 'login', 'register', 'profile'] as const).map((page, index) => <a className={data.page === page ? 'active' : ''} key={page} href={page === 'home' ? '#/' : `#/${page}`}><span className="pt-nav-glyph">{['⌂', '↗', '+', '○'][index]}</span>{pages[page]}</a>)}</nav><div className="pt-workspace-note"><span className="pt-workspace-note-icon">↗</span><strong>Mai bine, împreună.</strong><p>Resurse comune pentru proiectele comunității.</p></div><div className="pt-workspace-user"><span className="pt-avatar">{data.signedIn ? data.user.name.slice(0, 1) : 'S'}</span><div><strong>{data.signedIn ? data.user.name : 'Bun venit'}</strong><small>{data.signedIn ? 'Cont demonstrativ' : 'SpaceShare / Universitate'}</small></div></div></aside>
    <div className="pt-workspace-body"><header className="pt-workspace-topbar"><span>SpaceShare <span className="pt-breadcrumb-slash">/</span> <strong>{pages[data.page]}</strong></span><AccountLinks {...data} /></header>
      {data.page === 'home' ? <main className="pt-workspace-main"><p className="pt-overline">SPAȚIUL TĂU DE PORNIRE</p><h1>Bun venit în SpaceShare.</h1><p className="pt-workspace-lead">Toate resursele comune, organizate în jurul comunității.</p><section className="pt-workspace-welcome"><div><span className="pt-workspace-tag">ÎNVĂȚĂM. COLABORĂM. CONSTRUIM.</span><h2>Mai puțin timp căutând.<br />Mai mult timp creând.</h2><p>Începe cu un cont. Rezervările vin în etapele următoare.</p><a className="pt-button" href="#/register">Creează cont <span>↗</span></a></div><div className="pt-workspace-art" aria-hidden="true"><span /><span /><span /><b>↗</b></div></section><div className="pt-workspace-section-label"><h2>Ce vei găsi aici</h2><span>Resursele comunității</span></div><section className="pt-workspace-resources">{resources.map((item) => <article key={item.number}><span className="pt-resource-icon"><Icon name={item.icon} className="size-6" /></span><h3>{item.name}</h3><p>{item.text}</p><span className="pt-soon">Disponibil în etapele următoare</span></article>)}</section><div className="pt-workspace-info"><span>i</span><p>SpaceShare este în dezvoltare. Contul și profilul sunt punctul de pornire al aplicației.</p></div></main> : <main className="pt-workspace-main"><div className="pt-workspace-page-title"><div><p className="pt-overline">CONT ȘI PREFERINȚE</p><h1>{data.page === 'profile' ? 'Profilul meu' : pages[data.page]}</h1></div><span className="pt-workspace-status">{data.page === 'profile' ? 'Utilizator' : 'Comunitatea SpaceShare'}</span></div><div className="pt-workspace-account"><AccountForm key={data.page} {...data} /><aside className="pt-workspace-details"><span className="pt-avatar big">{data.page === 'profile' ? data.user.name.slice(0, 1) : 'S'}</span><h2>{data.page === 'profile' ? data.user.name : 'Un cont. Un singur loc.'}</h2><p>{data.page === 'profile' ? data.user.email : 'O experiență simplă pentru resursele pe care le folosim împreună.'}</p><div><span><Icon name="check" className="size-4" /> Date personale organizate</span><span><Icon name="check" className="size-4" /> Un profil pentru comunitate</span><span><Icon name="check" className="size-4" /> Acces simplu la cont</span></div><small>Rezervările și administrarea resurselor vor fi adăugate ulterior.</small></aside></div></main>}
    </div>
  </div>;
}

export function VariantC(data: PrototypeData) {
  return <div className="pt-atelier">
    <header className="pt-atelier-header"><Brand /><span className="pt-atelier-motto">FĂ LOC PENTRU CE CONTEAZĂ.</span><AccountLinks {...data} /></header>
    {data.page === 'home' ? <main><section className="pt-atelier-hero"><p className="pt-overline"><span /> O COMUNITATE, MAI MULTE POSIBILITĂȚI</p><h1>Idei mari.<br /><span>Loc pentru toate.</span></h1><div className="pt-atelier-hero-bottom"><p>Un spațiu de studiu. Un laborator. Echipamentul potrivit. Lucrurile bune se construiesc împreună.</p><a className="pt-atelier-round-link" href="#/register" aria-label="Creează un cont">↗</a><span>ÎNCEPE CU UN CONT<br /><strong>Fă parte din comunitate.</strong></span></div><span className="pt-atelier-orbit" aria-hidden="true" /></section><section className="pt-atelier-resources"><div className="pt-atelier-section-title"><p className="pt-overline">SPAȚII ȘI RESURSE COMUNE</p><h2>Ce aducem împreună.</h2></div>{resources.map((item) => <article key={item.number}><span className="pt-atelier-number">/{item.number}</span><h3>{item.name}</h3><p>{item.text}</p><Icon name={item.icon} className="size-7" /></article>)}</section><div className="pt-atelier-future"><p>Acum ne cunoaștem.<br /><strong>În curând, rezervăm.</strong></p><a href="#/register" className="pt-button">Creează cont <span>↗</span></a></div></main> : data.page === 'profile' ? <main><section className="pt-atelier-profile-heading"><span className="pt-overline">OAMENII DIN SPATELE IDEILOR</span><div><span className="pt-atelier-avatar">{data.user.name.slice(0, 1)}</span><h1>{data.user.name}<span>Acesta e spațiul tău.</span></h1><span className="pt-atelier-role">UTILIZATOR</span></div></section><div className="pt-atelier-profile-form"><div><p className="pt-overline">01 / DESPRE TINE</p><p>Detaliile mici<br />fac lucrurile<br /><em>personale.</em></p></div><AccountForm key={data.page} {...data} /></div></main> : <main className="pt-atelier-account"><aside><p className="pt-overline">SPACE FOR EVERYONE.</p><h1>Următoarea<br />idee bună<br />începe cu <em>tine.</em></h1><span className="pt-atelier-asterisk" aria-hidden="true">✳</span><p>Un loc pentru concentrare.<br />O comunitate pentru colaborare.</p><a href="#/">← Înapoi acasă</a></aside><AccountForm key={data.page} {...data} /></main>}
    <footer className="pt-atelier-footer"><span>SpaceShare <small>O idee de folosit împreună.</small></span><span>Proiect universitar / În dezvoltare</span></footer>
  </div>;
}
