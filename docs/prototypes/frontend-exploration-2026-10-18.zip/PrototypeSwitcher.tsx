import { useEffect } from 'react';
import { pages, variants, type FormState, type Page, type Variant } from '../pages/prototype/prototype.types';

export function PrototypeSwitcher({ variant, page, formState, signedIn, changeVariant, changePage, changeState }: {
  variant: Variant;
  page: Page;
  formState: FormState;
  signedIn: boolean;
  changeVariant: (variant: Variant) => void;
  changePage: (page: Page) => void;
  changeState: (state: FormState) => void;
}) {
  const keys: Variant[] = ['A', 'B', 'C'];
  function cycle(direction: number) {
    changeVariant(keys[(keys.indexOf(variant) + direction + keys.length) % keys.length]!);
  }
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof Element && target.closest('input, textarea, select, [contenteditable], [role="slider"]')) return;
      if (event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
        cycle(event.key === 'ArrowLeft' ? -1 : 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (!import.meta.env.DEV) return null;
  return <aside className="pt-switcher" aria-label="Controale pentru prototip">
    <div className="pt-switcher-main">
      <span className="pt-lab-label">PROTOTIP</span>
      <button type="button" onClick={() => cycle(-1)} aria-label="Varianta anterioară">←</button>
      <span className="pt-variant-label" aria-live="polite">{variant} · {variants[variant].name}</span>
      <button type="button" onClick={() => cycle(1)} aria-label="Varianta următoare">→</button>
      <label>Ecran<select value={page} onChange={(event) => changePage(event.target.value as Page)}>{Object.entries(pages).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label>
      <label>Stare<select value={formState} onChange={(event) => changeState(event.target.value as FormState)}><option value="normal">Normal</option><option value="error">Eroare</option><option value="loading">Încărcare</option><option value="success">Succes</option></select></label>
      <a href={window.location.hash || '#/'} onClick={(event) => {
        event.preventDefault();
        const url = new URL(window.location.href);
        url.searchParams.delete('variant');
        window.location.assign(url);
      }}>Aplicația actuală ↗</a>
    </div>
    <p role="status">{pages[page]} · {formState} · Sesiune: {signedIn ? 'demo conectat' : 'vizitator'} · Date fictive, doar în memorie · ← / → schimbă varianta</p>
  </aside>;
}
