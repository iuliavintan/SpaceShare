// Throwaway prototype: three visual systems for the four existing SpaceShare pages.
export type Variant = 'A' | 'B' | 'C';
export type Page = 'home' | 'login' | 'register' | 'profile';
export type FormState = 'normal' | 'error' | 'loading' | 'success';

export const variants = {
  A: { name: 'Campus editorial', description: 'O identitate universitară calmă: serif, linii fine și accente de teracotă.' },
  B: { name: 'Workspace', description: 'O aplicație de zi cu zi: navigare laterală, conținut compact și accente albastre.' },
  C: { name: 'Atelier', description: 'O identitate expresivă: contraste puternice, titluri mari și accente lime.' },
};

export const pages: Record<Page, string> = {
  home: 'Acasă', login: 'Autentificare', register: 'Înregistrare', profile: 'Profil',
};

export interface PrototypeData {
  page: Page;
  formState: FormState;
  signedIn: boolean;
  user: { name: string; email: string };
  saveUser: (user: { name: string; email: string }) => void;
  navigate: (page: Page) => void;
  signOut: () => void;
  setFormState: (state: FormState) => void;
}
