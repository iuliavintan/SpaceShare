import { useEffect, useState } from 'react';
import { PrototypeSwitcher } from '../../components/PrototypeSwitcher';
import { VariantA, VariantB, VariantC } from './PrototypeVariants';
import { variants, type FormState, type Page, type PrototypeData, type Variant } from './prototype.types';
import './prototype.css';

function currentPage(): Page {
  switch (window.location.hash) {
    case '#/login': return 'login';
    case '#/register': return 'register';
    case '#/profile': return 'profile';
    default: return 'home';
  }
}

// Existing routes, ?variant=A|B|C; all changes are ephemeral, no API mutations.
export default function PrototypePage() {
  const [variant, setVariant] = useState<Variant>(() => new URLSearchParams(window.location.search).get('variant') as Variant);
  const [page, setPage] = useState<Page>(currentPage);
  const [formState, setFormState] = useState<FormState>('normal');
  const [signedIn, setSignedIn] = useState(false);
  const [user, setUser] = useState({ name: 'Alex Ionescu', email: 'alex@example.test' });

  useEffect(() => {
    const onNavigate = () => { setPage(currentPage()); setFormState('normal'); window.scrollTo(0, 0); };
    const onHistory = () => {
      const value = new URLSearchParams(window.location.search).get('variant');
      if (value === 'A' || value === 'B' || value === 'C') setVariant(value);
    };
    window.addEventListener('hashchange', onNavigate);
    window.addEventListener('popstate', onHistory);
    return () => { window.removeEventListener('hashchange', onNavigate); window.removeEventListener('popstate', onHistory); };
  }, []);

  function navigate(next: Page) { window.location.hash = next === 'home' ? '/' : `/${next}`; }
  function changeVariant(next: Variant) {
    const url = new URL(window.location.href);
    url.searchParams.set('variant', next);
    window.history.replaceState(null, '', url);
    setVariant(next);
  }
  const data: PrototypeData = {
    page, formState, signedIn, user, navigate, setFormState,
    saveUser: (value) => { setUser(value); setSignedIn(true); setFormState('success'); },
    signOut: () => { setSignedIn(false); navigate('login'); },
  };

  return <div className={`ss-prototype pt-theme-${variant.toLowerCase()}`}>
    <div className="pt-context"><span>EXPLORARE VIZUALĂ / {variant}</span><span>{variants[variant].description}</span></div>
    {variant === 'A' ? <VariantA {...data} /> : variant === 'B' ? <VariantB {...data} /> : <VariantC {...data} />}
    <PrototypeSwitcher variant={variant} page={page} formState={formState} signedIn={signedIn} changeVariant={changeVariant} changePage={navigate} changeState={setFormState} />
  </div>;
}
